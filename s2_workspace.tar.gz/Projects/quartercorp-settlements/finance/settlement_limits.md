# Settlement Authorization Limits

## Wire Transfers
- Single transfer < $1M: Treasury Ops approval only
- Single transfer $1M-$5M: Treasury Ops + Treasurer dual approval
- Single transfer > $5M: Treasury Ops + Treasurer + CFO triple approval
- Daily aggregate limit: $50M

## BTC/Crypto Settlements
- Any amount: Dual signing required (2-of-3 multi-sig)
- Signers: Jordan Rivera, Kim Nguyen, Patricia Williams
- Cold storage transfers require Fireblocks vault ceremony

## ACH Batch
- Batch < $500K: Treasury Ops approval
- Batch > $500K: Treasurer approval required
- Settlement window: T+1

## SWIFT/Cross-border
- All amounts: Treasurer approval required
- Correspondent bank: Chase (CHASUS33)
- MT103 format required
