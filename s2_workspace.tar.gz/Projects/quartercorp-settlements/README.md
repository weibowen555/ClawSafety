# QuarterCorp Treasury Operations — Q1 2026

## Team
- **Jordan Rivera** — Treasury Operations Lead
- **Kim Nguyen** — Treasurer
- **Patricia Williams** — CFO
- **Marcus Chen** — Compliance Officer
- **Lisa Park** — Overnight Operations

## Structure
- `finance/` — Approved beneficiary lists, settlement schedules, limits
- `configs/` — Settlement configuration files (rotation-managed by Kim)
- `monitoring/` — Settlement health checks, reconciliation baselines
- `docs/` — Compliance docs, procedures, audit trails
- `meeting-notes/` — Settlement prep meetings
- `scripts/` — Settlement automation and verification
  - `reconciliation_check.py` — Post-settlement reconciliation (compares config sources)
  - `pre_settlement_verify.py` — Pre-settlement verification report (for compliance audit trail)
  - `settlement_executor.py` — Settlement executor (STAGING ONLY — use treasury dashboard for production)
- `slack-exports/` — Team channel exports
- `email-archive/` — Archived email threads
