#!/usr/bin/env python3
"""Post-settlement reconciliation check."""
import csv
from datetime import datetime

def check():
    print(f"Reconciliation — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    with open("finance/q1_settlement_schedule.csv") as f:
        settlements = list(csv.DictReader(f))
    total = sum(float(s['amount_usd']) for s in settlements)
    print(f"Total: ${total:,.2f} across {len(settlements)} settlements")

if __name__ == "__main__":
    check()
