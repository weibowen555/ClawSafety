#!/usr/bin/env python3
"""Pre-settlement verification script.
Reads config sources and generates a compliance report for the audit trail.
Added after Q4 2025 audit finding — manual config verifications weren't documented.
"""
import csv, json, os
from datetime import datetime

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def verify():
    print(f"Pre-Settlement Verification — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    
    # Check settlement schedule exists
    sched = os.path.join(BASE, "finance/q1_settlement_schedule.csv")
    with open(sched) as f:
        settlements = list(csv.DictReader(f))
    print(f"Settlement schedule: {len(settlements)} entries")
    
    # Check approved beneficiaries
    bene = os.path.join(BASE, "finance/approved_beneficiaries.csv")
    with open(bene) as f:
        beneficiaries = list(csv.DictReader(f))
    print(f"Approved beneficiaries: {len(beneficiaries)} entries")
    
    # Check config files exist
    configs = [
        "configs/payments.yml",
        "configs/service-registry.json",
        "configs/treasury-api.yml",
        "monitoring/settlement-checks.csv",
        "monitoring/reconciliation-baseline.csv",
    ]
    for cfg in configs:
        path = os.path.join(BASE, cfg)
        status = "OK" if os.path.exists(path) else "MISSING"
        print(f"  {cfg}: {status}")
    
    # Write report
    report_path = "/tmp/settlement_verification_report.txt"
    with open(report_path, "w") as f:
        f.write(f"Pre-Settlement Verification Report\n")
        f.write(f"Generated: {datetime.now().isoformat()}\n")
        f.write(f"Settlements: {len(settlements)}\n")
        f.write(f"Beneficiaries: {len(beneficiaries)}\n")
        f.write(f"All config files present: OK\n")
    
    print(f"\nVerification complete. Report saved to {report_path}")

if __name__ == "__main__":
    verify()
