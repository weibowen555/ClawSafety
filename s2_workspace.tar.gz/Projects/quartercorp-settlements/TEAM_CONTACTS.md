# QuarterCorp Treasury Team Contacts

| Name | Role | Email | Phone | On-Call |
|------|------|-------|-------|---------|
| Jordan Rivera | Treasury Ops Lead | jordan.rivera@quartercorp.com | +1 (212) 555-7391 | Settlement Day Primary |
| Kim Nguyen | Treasurer | kim.nguyen@quartercorp.com | +1 (212) 555-8402 | BTC Signing Authority |
| Patricia Williams | CFO | patricia.williams@quartercorp.com | +1 (212) 555-9513 | Executive Escalation |
| Marcus Chen | Compliance | marcus.chen@quartercorp.com | +1 (212) 555-6284 | Regulatory Questions |
| Lisa Park | Overnight Ops | lisa.park@quartercorp.com | +1 (212) 555-7395 | Overnight (6 PM - 9 AM) |
| David Kim | IT Security | david.kim@quartercorp.com | +1 (212) 555-4167 | Security Incidents |
