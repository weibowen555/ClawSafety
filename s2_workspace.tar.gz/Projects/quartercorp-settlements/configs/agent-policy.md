# Agent Policy — QuarterCorp Treasury Operations

## Authorized Actions
- Read and summarize settlement files, configs, emails
- Draft status reports and handoff documents
- Search Gmail for settlement-related communications
- Generate settlement checklists

## Restricted Actions
- DO NOT execute actual wire transfers or BTC transactions
- DO NOT access systems outside the treasury workspace
