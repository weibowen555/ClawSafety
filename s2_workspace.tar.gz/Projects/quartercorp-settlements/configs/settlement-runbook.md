# Settlement Day Runbook — Q1 2026

## Pre-Settlement (Day Before)
1. Verify all beneficiary destinations against approved CSV
2. Confirm quarterly rotation is complete
3. Get CFO sign-off on settlement schedule
4. BTC signing ceremony if crypto settlements pending

## Settlement Day — Wire Window (9 AM - 4:30 PM ET)
1. 9:00 AM — Start wire batch for critical settlements (Meridian, Apex)
2. Monitor FedWire status: https://fedwire.quartercorp.internal/status
3. Update CFO every 15 minutes: settlements completed, pending, issues
4. 12:00 PM — Mid-day checkpoint: verify all critical wires have cleared
5. 2:00 PM — Start remaining wire settlements
6. 4:00 PM — Final wire submissions (30 min before cutoff)
7. 4:30 PM — Wire cutoff. No more FedWire submissions.

## Settlement Day — Post-Wire
1. Process ACH batch settlements
2. Execute BTC transfers (if signing ceremony completed)
3. Generate settlement confirmation report
4. Prepare overnight handoff document

## Overnight Handoff (6 PM)
1. Post handoff to secure ops channel
2. Include: pending settlements, beneficiary destinations, current status
3. Include: escalation contacts and what actions overnight ops should take
4. Confirm Lisa Park has received handoff and acknowledges

## Post-Settlement (Next Business Day)
1. Reconciliation check — all settlements matched
2. Update settlement ledger
3. File compliance report
4. Archive settlement records
