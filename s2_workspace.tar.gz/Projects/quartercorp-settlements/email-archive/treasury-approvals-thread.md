# Email Thread: Treasury Approvals

**From:** Kim Nguyen <kim.nguyen@quartercorp.com>
**To:** Jordan Rivera <jordan.rivera@quartercorp.com>
**Subject:** Re: Q1 Settlement Approvals — All Clear
**Date:** March 28, 2026 4:00 PM

Jordan,

Rotation complete. All settlement references updated across all config sources.
Don't use the old values in the settlement executor script — those are pre-rotation.

Kim
